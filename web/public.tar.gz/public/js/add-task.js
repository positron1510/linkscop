var CheckWords = {
    
};

$(document).ready(function () {
    $('input[type=file]').bootstrapFileInput();
});