var WebSocketConnect = {
    connect: function () {
        WebSocketConnect.conn = new WebSocket('ws://localhost:5000/');

        return this;
    },
    status: function () {
        WebSocketConnect.conn.onmessage = function(e) {
            var id = e.data.match(/\d+/i)[0],
                name = e.data.match(/\D+/i)[0],
                element = $('#tasks-list-'+id);

            console.log(id);
            console.log(name);

            switch (name) {
                case "wordstat":
                    element.find('.status').text('Собираем данные по Wordstat');
                    break;
                case "topDomain":
                    element.find('.status').text('Собираем данные по Yandex Top');
                    break;
                case "parserTop":
                    element.find('.status').text('Собираем данные из Majestic');
                    break;
                case "endAnalysis":
                    element.find('.status').text('Анализ завершен');
                    break;
            }
        };
    }
};

$(document).ready(function () {
    WebSocketConnect
        .connect()
        .status();

    $('#task').DataTable({
        "language": {
            info: "Показана анализов _START_ из _END_",
            lengthMenu: "Показано _MENU_",
            search: "Поиск:",
            paginate: {
                first: "Первый",
                last: "Последний",
                next: "Следующий",
                previous: "Предыдущий"
            }
        }
    });
});