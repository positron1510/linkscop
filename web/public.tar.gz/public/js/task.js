$(document).ready(function () {
    var options = {
        "paging": false,
        "order": [[ 1, "desc" ]],
        "language": {
            info: "Показана запросов _START_ из _END_",
            search: "Поиск:"
        }
    };

    $('.task-words').DataTable(options);
    $('.task-domain').DataTable(options);
});